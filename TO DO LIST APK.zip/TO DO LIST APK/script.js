// DOM Elements
const taskInput = document.getElementById('taskInput');
const addTaskBtn = document.getElementById('addTask');
const taskList = document.getElementById('taskList');
const emptyState = document.getElementById('emptyState');
const filterBtns = document.querySelectorAll('.filter-btn');
const totalCount = document.getElementById('totalCount');
const completedPercent = document.getElementById('completedPercent');
const progressBar = document.getElementById('progressBar');
const settingsBtn = document.getElementById('settingsBtn');
const settingsMenu = document.getElementById('settingsMenu');
const printBtn = document.getElementById('printBtn');
const printAllBtn = document.getElementById('printAllBtn');
const printCompletedBtn = document.getElementById('printCompletedBtn');
const localStorageBtn = document.getElementById('localStorageBtn');
const sessionStorageBtn = document.getElementById('sessionStorageBtn');
const clearStorageBtn = document.getElementById('clearStorageBtn');
const currentStorage = document.getElementById('currentStorage');
const storedCount = document.getElementById('storedCount');
const historyBtn = document.getElementById('historyBtn');
const historyModal = document.getElementById('historyModal');
const historyContent = document.getElementById('historyContent');
const closeModal = document.querySelector('.close-modal');
const downloadPdf = document.getElementById('downloadPdf');
const historyFilter = document.getElementById('historyFilter');

// State variables
let tasks = [];
let taskHistory = [];
let currentFilter = 'all';
let storageType = 'local';

// Initialize the app
function init() {
    loadTasks();
    loadHistory();
    renderTasks();
    updateStats();
    updateStorageInfo();
    
    if (tasks.length === 0) {
        addSampleTasks();
    }
}

// Sample tasks
function addSampleTasks() {
    tasks = [
        { id: 1, text: "Buy groceries", completed: false },
        { id: 2, text: "Do laundry", completed: false },
        { id: 3, text: "Finish project", completed: true }
    ];
    saveTasks();
    
    // Add sample history
    tasks.forEach(task => {
        if (task.completed) {
            logHistory('completed', task);
        } else {
            logHistory('added', task);
        }
    });
}

// Storage functions
function getStorage() {
    return storageType === 'local' ? localStorage : sessionStorage;
}

function loadTasks() {
    const savedTasks = getStorage().getItem('tasks');
    tasks = savedTasks ? JSON.parse(savedTasks) : [];
}

function loadHistory() {
    const savedHistory = getStorage().getItem('taskHistory');
    taskHistory = savedHistory ? JSON.parse(savedHistory) : [];
}

function saveTasks() {
    getStorage().setItem('tasks', JSON.stringify(tasks));
    updateStorageInfo();
}

function saveHistory() {
    getStorage().setItem('taskHistory', JSON.stringify(taskHistory));
}

function updateStorageInfo() {
    currentStorage.textContent = storageType === 'local' ? 'Local Storage' : 'Session Storage';
    storedCount.textContent = tasks.length;
}

// Task functions
function addTask() {
    const text = taskInput.value.trim();
    if (text === '') return;
    
    const newTask = {
        id: Date.now(),
        text,
        completed: false
    };
    
    tasks.push(newTask);
    logHistory('added', newTask);
    saveTasks();
    renderTasks();
    updateStats();
    
    taskInput.value = '';
    taskInput.focus();
}

function toggleTask(id) {
    tasks = tasks.map(task => {
        if (task.id === id) {
            const updatedTask = { ...task, completed: !task.completed };
            logHistory(task.completed ? 'uncompleted' : 'completed', updatedTask);
            return updatedTask;
        }
        return task;
    });
    
    saveTasks();
    renderTasks();
    updateStats();
}

function deleteTask(id) {
    if (confirm('Are you sure you want to delete this task?')) {
        const taskToDelete = tasks.find(task => task.id === id);
        if (taskToDelete) {
            logHistory('deleted', taskToDelete);
        }
        tasks = tasks.filter(task => task.id !== id);
        saveTasks();
        renderTasks();
        updateStats();
    }
}

// History functions
function logHistory(action, task) {
    const historyItem = {
        action,
        task: { ...task },
        timestamp: new Date()
    };
    taskHistory.push(historyItem);
    saveHistory();
}

function renderHistory(filter = 'all') {
    let filteredHistory = taskHistory;
    
    if (filter !== 'all') {
        filteredHistory = taskHistory.filter(item => item.action.includes(filter));
    }
    
    if (filteredHistory.length === 0) {
        historyContent.innerHTML = '<div class="empty-history">No history found</div>';
        return;
    }
    
    historyContent.innerHTML = '';
    
    const historyByDate = {};
    filteredHistory.forEach(item => {
        const dateStr = new Date(item.timestamp).toLocaleDateString();
        if (!historyByDate[dateStr]) {
            historyByDate[dateStr] = [];
        }
        historyByDate[dateStr].push(item);
    });
    
    const sortedDates = Object.keys(historyByDate).sort((a, b) => 
        new Date(b) - new Date(a));
    
    sortedDates.forEach(date => {
        const dateHeader = document.createElement('h3');
        dateHeader.textContent = date;
        historyContent.appendChild(dateHeader);
        
        historyByDate[date].sort((a, b) => 
            new Date(b.timestamp) - new Date(a.timestamp));
        
        historyByDate[date].forEach(item => {
            const historyItem = document.createElement('div');
            historyItem.className = `history-item ${item.action}`;
            
            let icon, actionText;
            switch(item.action) {
                case 'added':
                    icon = 'fa-plus-circle';
                    actionText = 'Task added';
                    break;
                case 'completed':
                    icon = 'fa-check-circle';
                    actionText = 'Task completed';
                    break;
                case 'uncompleted':
                    icon = 'fa-undo';
                    actionText = 'Task marked incomplete';
                    break;
                case 'deleted':
                    icon = 'fa-trash';
                    actionText = 'Task deleted';
                    break;
                default:
                    icon = 'fa-edit';
                    actionText = 'Task updated';
            }
            
            const timeStr = new Date(item.timestamp).toLocaleTimeString([], 
                { hour: '2-digit', minute: '2-digit' });
            
            historyItem.innerHTML = `
                <div class="history-icon"><i class="fas ${icon}"></i></div>
                <div class="history-details">
                    <div class="history-action">${actionText}</div>
                    <div class="history-task">${item.task.text}</div>
                    <div class="history-time">${timeStr}</div>
                </div>
            `;
            
            historyContent.appendChild(historyItem);
        });
    });
}

function generateHistoryPdf() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    doc.setFontSize(20);
    doc.setTextColor(74, 111, 165);
    doc.text('Task History Report', 105, 20, { align: 'center' });
    
    doc.setFontSize(12);
    doc.setTextColor(100, 100, 100);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 105, 30, { align: 'center' });
    
    let y = 40;
    const lineHeight = 8;
    const pageHeight = doc.internal.pageSize.height - 20;
    
    const historyByDate = {};
    taskHistory.forEach(item => {
        const dateStr = new Date(item.timestamp).toLocaleDateString();
        if (!historyByDate[dateStr]) {
            historyByDate[dateStr] = [];
        }
        historyByDate[dateStr].push(item);
    });
    
    const sortedDates = Object.keys(historyByDate).sort((a, b) => 
        new Date(b) - new Date(a));
    
    sortedDates.forEach(date => {
        if (y > pageHeight) {
            doc.addPage();
            y = 20;
        }
        
        doc.setFontSize(14);
        doc.setTextColor(74, 111, 165);
        doc.text(date, 14, y);
        y += lineHeight + 2;
        
        doc.setFontSize(10);
        doc.setTextColor(0, 0, 0);
        
        historyByDate[date].sort((a, b) => 
            new Date(b.timestamp) - new Date(a.timestamp));
        
        historyByDate[date].forEach(item => {
            if (y > pageHeight) {
                doc.addPage();
                y = 20;
            }
            
            let icon, actionText, textColor;
            switch(item.action) {
                case 'added':
                    icon = '+';
                    actionText = 'Added';
                    textColor = [74, 111, 165];
                    break;
                case 'completed':
                    icon = '✓';
                    actionText = 'Completed';
                    textColor = [76, 175, 80];
                    break;
                case 'uncompleted':
                    icon = '↩';
                    actionText = 'Marked Incomplete';
                    textColor = [243, 156, 18];
                    break;
                case 'deleted':
                    icon = '×';
                    actionText = 'Deleted';
                    textColor = [244, 67, 54];
                    break;
                default:
                    icon = '•';
                    actionText = 'Updated';
                    textColor = [0, 0, 0];
            }
            
            const timeStr = new Date(item.timestamp).toLocaleTimeString([], 
                { hour: '2-digit', minute: '2-digit' });
            
            doc.setTextColor(textColor);
            doc.text(`${icon} [${timeStr}] ${actionText}: ${item.task.text}`, 20, y);
            y += lineHeight;
        });
        
        y += lineHeight;
    });
    
    doc.save(`task-history-${new Date().toISOString().slice(0,10)}.pdf`);
}

// Render tasks
function renderTasks() {
    let filteredTasks = [];
    
    if (currentFilter === 'all') {
        filteredTasks = [...tasks];
    } else if (currentFilter === 'active') {
        filteredTasks = tasks.filter(task => !task.completed);
    } else if (currentFilter === 'completed') {
        filteredTasks = tasks.filter(task => task.completed);
    }
    
    if (filteredTasks.length === 0) {
        emptyState.style.display = 'flex';
        taskList.innerHTML = '';
        taskList.appendChild(emptyState);
        return;
    }
    
    emptyState.style.display = 'none';
    taskList.innerHTML = '';
    
    filteredTasks.forEach(task => {
        const taskElement = document.createElement('div');
        taskElement.className = `task-item ${task.completed ? 'completed' : ''}`;
        
        taskElement.innerHTML = `
            <input type="checkbox" class="task-checkbox" ${task.completed ? 'checked' : ''}>
            <div class="task-text">${task.text}</div>
            <div class="task-actions">
                <button class="action-btn delete-btn">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        
        const checkbox = taskElement.querySelector('.task-checkbox');
        checkbox.addEventListener('change', () => toggleTask(task.id));
        
        const deleteBtn = taskElement.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', () => deleteTask(task.id));
        
        taskList.appendChild(taskElement);
    });
}

// Update stats
function updateStats() {
    const total = tasks.length;
    const completed = tasks.filter(task => task.completed).length;
    const percent = total > 0 ? Math.round((completed / total) * 100) : 0;
    
    totalCount.textContent = total;
    completedPercent.textContent = `${percent}%`;
    progressBar.style.width = `${percent}%`;
    
    if (percent < 30) {
        progressBar.style.background = 'linear-gradient(90deg, #f44336 0%, #e74c3c 100%)';
    } else if (percent < 70) {
        progressBar.style.background = 'linear-gradient(90deg, #ff9800 0%, #f39c12 100%)';
    } else {
        progressBar.style.background = 'linear-gradient(90deg, #4caf50 0%, #2ecc71 100%)';
    }
}

// Filter tasks
function setFilter(filter) {
    currentFilter = filter;
    filterBtns.forEach(btn => {
        btn.classList.toggle('active', btn.dataset.filter === filter);
    });
    renderTasks();
}

// Print tasks
function printTasks(type) {
    let tasksToPrint = [];
    
    if (type === 'completed') {
        tasksToPrint = tasks.filter(task => task.completed);
    } else {
        tasksToPrint = [...tasks];
    }
    
    if (tasksToPrint.length === 0) {
        alert(`No ${type === 'completed' ? 'completed' : ''} tasks to print!`);
        return;
    }
    
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>My Tasks - ${type === 'completed' ? 'Completed' : 'All'} Tasks</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 30px; }
                h1 { color: #4a6fa5; text-align: center; margin-bottom: 30px; }
                ul { list-style-type: none; padding: 0; max-width: 600px; margin: 0 auto; }
                li { padding: 12px; border-bottom: 1px solid #eee; display: flex; align-items: center; 
                      font-size: 1.1rem; margin-bottom: 8px; }
                .completed { text-decoration: line-through; color: #777; }
                .check-icon { color: #4CAF50; margin-right: 12px; font-size: 1.2rem; }
                .print-date { text-align: center; margin-top: 30px; color: #777; font-size: 0.9rem; }
                .print-header { text-align: center; margin-bottom: 20px; }
                .print-title { font-size: 1.8rem; color: #4a6fa5; margin-bottom: 5px; }
                .print-subtitle { color: #666; margin-bottom: 30px; }
            </style>
        </head>
        <body>
            <div class="print-header">
                <h1 class="print-title">My Tasks</h1>
                <div class="print-subtitle">${type === 'completed' ? 'Completed Tasks' : 'All Tasks'}</div>
            </div>
            <ul>
    `);
    
    tasksToPrint.forEach(task => {
        printWindow.document.write(`
            <li class="${task.completed ? 'completed' : ''}">
                <i class="fas ${task.completed ? 'fa-check-circle check-icon' : 'fa-circle'}"></i>
                ${task.text}
            </li>
        `);
    });
    
    const now = new Date();
    printWindow.document.write(`
            </ul>
            <div class="print-date">
                Printed on: ${now.toLocaleDateString()} at ${now.toLocaleTimeString()}
            </div>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"><\/script>
        </body>
        </html>
    `);
    
    printWindow.document.close();
    setTimeout(() => {
        printWindow.print();
    }, 500);
}

// Change storage type
function changeStorageType(type) {
    storageType = type;
    
    const oldStorage = type === 'local' ? sessionStorage : localStorage;
    const newStorage = getStorage();
    
    const tasksData = oldStorage.getItem('tasks');
    if (tasksData) {
        newStorage.setItem('tasks', tasksData);
        oldStorage.removeItem('tasks');
    }
    
    const historyData = oldStorage.getItem('taskHistory');
    if (historyData) {
        newStorage.setItem('taskHistory', historyData);
        oldStorage.removeItem('taskHistory');
    }
    
    loadTasks();
    loadHistory();
    renderTasks();
    updateStats();
    updateStorageInfo();
    
    alert(`Storage changed to ${type === 'local' ? 'Local Storage' : 'Session Storage'}`);
}

// Clear all data
function clearAllData() {
    if (confirm('Are you sure you want to clear all data? This cannot be undone.')) {
        localStorage.removeItem('tasks');
        sessionStorage.removeItem('tasks');
        localStorage.removeItem('taskHistory');
        sessionStorage.removeItem('taskHistory');
        tasks = [];
        taskHistory = [];
        saveTasks();
        saveHistory();
        renderTasks();
        updateStats();
        updateStorageInfo();
        alert('All data has been cleared!');
    }
}

// Event Listeners
addTaskBtn.addEventListener('click', addTask);
taskInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTask();
});

filterBtns.forEach(btn => {
    btn.addEventListener('click', () => setFilter(btn.dataset.filter));
});

settingsBtn.addEventListener('click', () => {
    settingsMenu.classList.toggle('active');
});

printBtn.addEventListener('click', () => printTasks('all'));
printAllBtn.addEventListener('click', () => printTasks('all'));
printCompletedBtn.addEventListener('click', () => printTasks('completed'));

localStorageBtn.addEventListener('click', () => changeStorageType('local'));
sessionStorageBtn.addEventListener('click', () => changeStorageType('session'));
clearStorageBtn.addEventListener('click', clearAllData);

historyBtn.addEventListener('click', () => {
    renderHistory();
    historyModal.style.display = 'block';
});

closeModal.addEventListener('click', () => {
    historyModal.style.display = 'none';
});

window.addEventListener('click', (e) => {
    if (e.target === historyModal) {
        historyModal.style.display = 'none';
    }
});

historyFilter.addEventListener('change', (e) => {
    renderHistory(e.target.value);
});

downloadPdf.addEventListener('click', generateHistoryPdf);

// Initialize the app
init();